
export type Status = 'idle' | 'loading' | 'success' | 'error';
