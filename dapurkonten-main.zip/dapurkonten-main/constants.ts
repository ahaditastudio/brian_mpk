export const N8N_WEBHOOK_URL = 'https://n8n.codelatte.my.id/webhook/1bb34ae5-8e9a-4bc2-a3be-faa38b4ead7e';
